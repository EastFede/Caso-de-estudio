# CASO DE ESTUDIO

### Franquicias Panadería:

[Contrato de Franquicia](https://www.notion.so/Contrato-de-Franquicia-184c5da6aa554f4f80931649fac4492b?pvs=21)

Obs. Tiene interés en tener distribución///como seria?:  (preguntas como capacidad Osciosa, costos bien calculados(distribucion))

### Oportunidad: capitalista interesado

-Formar una nueva SAS

-Nuevo local     

### Interrogante:

-% de participación 

Uno pone el capital y el otro el Know How 

-Venta entre empresas

 

estudio del caso :

Supongamos el siguiente caso, cliente con un negocio de panadería con dos locales, innovador y con buenas perspectivas, recientemente abro un cafe en una de ellas. hace tres anos y las ventas no han parado de crecer. Se acerca un interesado en desarrollar un cafe de similares características al antes descrito, para lo cual la titular de la empresa antes mencionada se encargara de desarrollar y gestionar el mismo, dado todo el Know-how. La  panadería va a suministrar la parte de alimentos.  Para este caso, se describe cuales puede ser las posibilidades de negocio que se presentan, en particular: porcentaje en la nueva sociedad, porcentaje de margen para la venta de productos de panaderia entre locales, porcentaje de regalias bruta como pago fijo por concepto de servicos. Resolveremos el caso paso a paso.

Primero, es importante entender los términos del acuerdo. Esto significa que debe establecerse un acuerdo entre el interesado y el propietario de la panadería. El acuerdo debe incluir los términos y condiciones de la nueva sociedad, el porcentaje de participación de cada parte, el porcentaje de margen para la venta de productos de panadería entre los locales, el porcentaje de regalías brutas como pago fijo por los servicios del propietario de la panadería, etc.

Una vez que se hayan establecido los términos del acuerdo, el propietario de la panadería debe determinar el porcentaje de participación en la nueva sociedad. Esto se puede hacer de varias maneras, como por ejemplo, estableciendo un porcentaje de participación basado en el capital invertido por cada parte, o bien, estableciendo un porcentaje de participación basado en el valor de la marca de la panadería.

Una vez que se haya establecido el porcentaje de participación, el propietario de la panadería debe determinar el porcentaje de margen para la venta de productos de panadería entre los locales. Esto se puede hacer de varias maneras, como por ejemplo, estableciendo un porcentaje de margen basado en el costo de los productos, o bien, estableciendo un porcentaje de margen basado en el precio de venta.

Finalmente, el propietario de la panadería debe determinar el porcentaje de regalías brutas como pago fijo por los servicios. Esto se puede hacer de varias maneras, como por ejemplo, estableciendo un porcentaje de regalías basado en el valor de los servicios prestados, o bien, estableciendo un porcentaje de regalías basado en el valor de la marca de la panadería.

En resumen, para este caso, las posibilidades de negocio que se presentan son: establecer un porcentaje de participación en la nueva sociedad, establecer un porcentaje de margen para la venta de productos de panadería entre los locales, y establecer un porcentaje de regalías brutas como pago fijo por los servicios del propietario de la panadería.

Etapas de la ejecución del negocio (4E):

<aside>
💡 ESTUDIO

</aside>

<aside>
💡 EJECUCION

</aside>

<aside>
💡 EJERCICIO

</aside>

<aside>
💡 EVALUACION

</aside>